<html>
	<head>
		<title>test</title>
	</head>
	<body>
		
		<?php
			/*$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_URL, 
			    'http://54.208.240.211//response.php?foo=yes we can&baz=foo bar'
			);
			$content = curl_exec($ch);
			echo $content;*/

			$host = "54.208.240.211";
			$dbuser = "root";
			$pass = "password";
			$dbname = "phpMyAdmin";
			$conn = mysqli_connect($host, $dbuser, $pass, $dbname);
			if(mysqli_connect_errno()){
				echo "connection failed";
			}
		?>
		<p>lkjnkjk</p>
	</body>
</html>