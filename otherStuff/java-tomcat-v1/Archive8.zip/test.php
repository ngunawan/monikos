<html>
	<head>
		<title>test</title>
	</head>
	<body>
		
		<?php
			/*$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_URL, 
			    'http://54.208.240.211//response.php?foo=yes we can&baz=foo bar'
			);
			$content = curl_exec($ch);
			echo $content;*/

			$host = "phpmyadmin.ci7ganrx1sxe.us-east-1.rds.amazonaws.com:3306";
			$dbuser = "phpMyAdmin";
			$pass = "phpMyAdmin";
			$dbname = "phpMyAdminDatabase";
			$conn = mysqli_connect($host, $dbuser, $pass, $dbname);
			if(mysqli_connect_errno()){
//				echo "connection failed" .mysqli_connect_error();
				die("Connection Failed" . mysqli_connect_error());
			}else{
				echo "connection sucessful";
			}

			$sql = "SELECT * FROM testtable";
			$res = mysqli_query($conn, $sql);
			if(!$res){
				die("Query failed");
			}
			while($row=mysqli_fetch_row($res)){
				var_dump($row);
				echo "<br /><hr /><br />";
			}
			mysqli_free_result($res);

		?>


		<p>lkjnkjk</p>
	</body>
</html>